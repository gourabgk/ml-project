# Program to make a simple
# login screen
from tkinter import *
from tkinter import ttk
import numpy as np
import pickle
import sklearn

root = Tk()
root.title("Car Price")

# setting the windows size
root.geometry("700x500")

# declaring string variable
year_var = StringVar()
showroom_var = StringVar()
kilometre_var = StringVar()
#owners_var = StringVar()
fuel_var = StringVar()
dealer_or_individual_var = StringVar()
manual_or_automatic_var = StringVar()



model = pickle.load(open('mypkl.pkl', 'rb'))

# defining a function that will
# get the name and password and
# print them on the screen
def submit():
	
	Year =int( year_var.get())
	Present_Price = float(showroom_var.get())
	Kms_Driven = int(kilometre_var.get())
	Kms_Driven2=np.log(Kms_Driven)
	#Owner = int(owners_var.get())
    
	Fuel_Type_Petrol = fuel_var.get()
	if(Fuel_Type_Petrol=='Petrol'):
		Fuel_Type_Petrol=1
		Fuel_Type_Diesel=0
		
	elif(Fuel_Type_Petrol=='Diesel'):
		Fuel_Type_Petrol=0
		Fuel_Type_Diesel=1
		
	else:
		Fuel_Type_Petrol=0
		Fuel_Type_Diesel=0
	
    
		
	Year=2020-Year
		
	Seller_Type_Individual= dealer_or_individual_var.get()
	if(Seller_Type_Individual=='Individual'):
		Seller_Type_Individual=1
	else:
		Seller_Type_Individual=0
	
	Transmission_Mannual = manual_or_automatic_var.get()
	if(Transmission_Mannual=='Manual'):
		Transmission_Mannual=1
	else:
		Transmission_Mannual=0
		
	prediction=model.predict([[Present_Price,Kms_Driven2,Year,Fuel_Type_Diesel,Fuel_Type_Petrol,Seller_Type_Individual,Transmission_Mannual]])
	output=round(prediction[0],2)
    
    
    
	print("Year:",Year)
	print("The present price : ",Present_Price)
	print("Kilometre  : ",Kms_Driven)
	#print("No. of Owners is : ",Owner )
	print("Fuel Type is : ",Fuel_Type_Petrol)
	print("Are you a Dealer or Individual : ",Seller_Type_Individual)
	print("Transmission type : ",Transmission_Mannual)

	#print("THe prediction price is:-",prediction)
	print("THe price is:-",output)
	year_var.set("")
	showroom_var.set("")

	result_entry.insert(0,output)
	kilometre_var.set("")

# creating a label fort
# name using widget Label

year_label = Label(root, text='Purchased Year', font=('calibre', 12, 'bold'))

year_entry = Entry(root, textvariable=year_var, font=('calibre', 12, 'bold'))

showroom_label = Label(root, text='Showroom Price (in Lakhs) ', font=('calibre', 12, 'bold'))

showroom_entry = Entry(root, textvariable=showroom_var, font=('calibre', 12, 'bold'))


kilometre_label = Label(root, text='Kilometre Driven ', font=('calibre', 12, 'bold'))

kilometre_entry = Entry(root, textvariable=kilometre_var, font=('calibre', 12, 'bold'))


#owners_label = Label(root, text='No. of Owners is', font=('calibre', 10, 'bold'))

# creating combobox
#owners_combo = ttk.Combobox(root, width=20, textvariable=owners_var)
# Adding combobox drop down list
#owners_combo['values'] = ('0', '1', '3')
#owners_combo.current(0)


fuel_label = Label(root, text='Fuel Type is', font=('calibre', 12, 'bold'))

# creating combobox
fuel_combo = ttk.Combobox(root, width=20, textvariable=fuel_var)
# Adding combobox drop down list
fuel_combo['values'] = ('Petrol', 'Diesel', 'CNG')
fuel_combo.current(0)

di_label = Label(root, text='Are you a Dealer or Individual?', font=('calibre', 12, 'bold'))

# creating combobox
di_combo = ttk.Combobox(root, width=20, textvariable=dealer_or_individual_var)
# Adding combobox drop down list
di_combo['values'] = ('Individual', 'Dealer')
di_combo.current(0)

tran_label = Label(root, text='Transmission Type', font=('calibre', 12, 'bold'))

# creating combobox
tran_combo = ttk.Combobox(root, width=20, textvariable=manual_or_automatic_var)
# Adding combobox drop down list
tran_combo['values'] = ('Manual', 'Automatic')
tran_combo.current(0)
# creating a button using the widget
# Button that will call the submit function
sub_btn = Button(root, text='CALCULATE SELLING PRICE', command=submit)

pat1 = Label(root, text='***************************************', font=('calibre', 12, 'bold'))

pat2 = Label(root, text="***************************************", font=('calibre', 12, 'bold'))

result=Label(root, text="Predicted selling price=", font=('calibre', 12, 'bold'))
result_entry = Entry(root)




# placing the label and entry in
# the required position using grid
# method
year_label.grid(column=0, row=0)
year_entry.grid(column=1, row=0)

showroom_label.grid(column=0, row=2)
showroom_entry.grid(column=1, row=2)

kilometre_label.grid(column=0, row=4)
kilometre_entry.grid(column=1, row=4)

#owners_label.grid(column=0, row=6)
#owners_combo.grid(column=1, row=6)

fuel_label.grid(column=0, row=6)
fuel_combo.grid(column=1, row=6)

di_label.grid(column=0, row=8)
di_combo.grid(column=1, row=8)

tran_label.grid(column=0, row=10)
tran_combo.grid(column=1, row=10)


sub_btn.grid( column=1, row=12)

pat1.grid(column=0,row=13)
pat2.grid(column=0,row=14)

result.grid(column=0,row=15)
result_entry.grid(column=1,row=15)

# performing an infinite loop
# for the window to display
root.mainloop()
