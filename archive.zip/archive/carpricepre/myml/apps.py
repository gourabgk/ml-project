from django.apps import AppConfig


class MymlConfig(AppConfig):
    name = 'myml'
